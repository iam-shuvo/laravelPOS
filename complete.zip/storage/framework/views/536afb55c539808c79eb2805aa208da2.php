<div class="container-fluid pt-4 px-4 ">
                <div class="bg-secondary rounded-top p-4">
                    <div class="row">
                        <div class="col-12 col-sm-6 text-center text-sm-start ">
                           <div class="bf-info">Stor Management </div>
                        </div>
                        <div class="col-12 col-sm-6 text-center text-sm-end">
                           
                            <div class="bf-info"> Designed By <a href="https://htmlcodex.com">Bristy Talukder</a>
                                <br>www.website: <a href="https://themewagon.com" target="_blank">Bristy@gmail.com</a> </div>
                           
                        </div>
                    </div>
                </div>
            </div><?php /**PATH E:\Xampp\htdocs\mirazvai_pos\laravelPosGroup4IDB-main\resources\views/layout/footer.blade.php ENDPATH**/ ?>