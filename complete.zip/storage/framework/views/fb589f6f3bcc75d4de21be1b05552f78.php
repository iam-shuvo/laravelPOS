<?php $__env->startSection("content"); ?>


<div class="col-sm-12 col-xl-12">
    <div class="p-4 rounded bg-light text-dark h-100">
        <h6 class="mb-4">Add Category</h6>

          <form form action="<?php echo e(route('pro_add')); ?>" method="POST" enctype='multipart/form-data'>
               <?php echo csrf_field(); ?>

              <div class="mb-3">
                    <label for="exampleInputProduct1" class="form-label">Product Name :</label>
                    <input type="text" class="form-control bg-white" id="exampleInputProduct1" placeholder="Enter product name" name="product_name"
                    aria-describedby="ProductHelp">
              </div>

              <div class="mb-3">
                    <label for="exampleInputProduct2" class="form-label">Description :</label>
                    <input type="text" class="form-control bg-white" id="exampleInputProduct2" placeholder="Enter description name" name="description"
                    aria-describedby="ProductHelp">
              </div>

              <div class="mb-3">
                    <label for="exampleInputProduct3" class="form-label">Product Image:</label>
                    <input type="file" class="form-control bg-white" id="exampleInputProduct3" placeholder="choosse your file" name="product_image"
                    aria-describedby="ProductHelp">
              </div>

              <div class="mb-3">
                    <label for="exampleInputProduct4" class="form-label">Catagories Name:</label>
                    <select class="form-control bg-white" aria-label="Default select example" name="category_id">
                  <option value="">please Select Categorie</option>
                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($row->id); ?>" <?php echo e(old('') == $row->id ? 'selected' : ''); ?>><?php echo e($row->category_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>

              <div class="mb-3">
                    <label for="exampleInputProduct5" class="form-label">Brand Name:</label>
                    <select class="form-control bg-white" aria-label="Default select example" name="brand_id">
                  <option value="">please Select Brand</option>
                  <?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($row->id); ?>" <?php echo e(old('') == $row->id ? 'selected' : ''); ?>><?php echo e($row->brand_name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
              </div>

              <div class="mb-3">
                    <label for="exampleInputProduct6" class="form-label">Unit Name :</label>
                    <select class="form-control bg-white" aria-label="Default select example" name="unit_id">
                  <option value="">please Select Unit</option>
                   <?php $__currentLoopData = $unit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($row->id); ?>" <?php echo e(old('') == $row->id ? 'selected' : ''); ?>><?php echo e($row->unit_name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>

              <div class="mb-3">
                    <label for="exampleInputProduct7" class="form-label">Selling Price:</label>
                    <input type="text" class="form-control bg-white" id="exampleInputCategory" placeholder="Enter selling price" name="selling_price"
                    aria-describedby="ProductHelp">
              </div>

              <div class="mb-3">
                    <label for="exampleInputProduct8" class="form-label">Buying Price:</label>
                    <input type="text" class="form-control bg-white" id="exampleInputProduct8" placeholder="Enter buying price" name="buying_price"
                    aria-describedby="ProductHelp">
              </div>

              <div class="mb-3">
                    <label for="exampleInputProduct9" class="form-label">SKU:</label>
                    <input type="text" class="form-control bg-white" id="exampleInputProduct9" placeholder="Enter SKU " name="sku"
                    aria-describedby="ProductHelp">
              </div>

              <div class="mb-3">
                    <label for="exampleInputProduct10" class="form-label">Product Status:</label>
                    <input type="text" class="form-control bg-white" id="exampleInputProduct10" placeholder="Enter Product Status " name="product_status"
                    aria-describedby="ProductHelp">
              </div>

               <button type="submit" class="btn btn-info">Submit</button>
           </form>
      </div>
</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make("master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\mirazvai_posupdate1\mirazvai_pos\laravelPosGroup4IDB-main\resources\views/pages/products/add_products.blade.php ENDPATH**/ ?>