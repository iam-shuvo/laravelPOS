<?php $__env->startSection("content"); ?>
 
<div class="col-sm-12 col-xl-12">
    <div class="bg-secondary rounded h-100 p-4">
        <h6 class="mb-4">Add Category</h6>
        <form form action="<?php echo e(route('category_add')); ?>" method="POST">
               <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="exampleInputCategory" class="form-label">Category Name :</label>
                    <input type="text" class="form-control" id="exampleInputCategory" placeholder="Enter category name" name="category_name"
                    aria-describedby="categoryHelp">
                </div>
                <button type="submit" class="btn btn-info">Submit</button>
         </form>
                
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravelPosGroup4IDB-main\resources\views/pages/Categories/addCategories.blade.php ENDPATH**/ ?>