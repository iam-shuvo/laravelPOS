<?php $__env->startSection("content"); ?>

<div class="col-sm-12 col-xl-12">
    <div class="bg-light rounded h-100 p-4">
        <h6 class="mb-4">All Suppliers</h6>
            <table class="table text-dark">
                <thead>
                    <tr>
                        <th scope="col">Suppliers Id</th>
                        <th scope="col">Suppliers Name</th>
                        <th scope="col">Suppliers Address</th>
                        <th scope="col">Suppliers Phone</th>
                        <th scope="col">Suppliers Email</th>
                        <th scope="col">Actions</th>
                    </tr>
                </thead>
                    <tbody>
                       <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                            <td><?php echo e($row->id); ?></td>
                            <td><?php echo e($row->supp_name); ?></td>
                            <td><?php echo e($row->supp_address); ?></td>
                            <td><?php echo e($row->supp_phone); ?></td>
                            <td><?php echo e($row->supp_email); ?></td>
                            <td><a href="supp_edit/<?php echo e($row->supp_id); ?>/user" class="btn btn-success">Edit</a>
                            <a href="supp_delete/<?php echo e($row->supp_id); ?>" class="btn btn-danger">Delete</a></td>
                            </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
            </table>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\fiamal\laravelPosGroup4IDB-main\resources\views/pages/Suppliers/viewSuppliers.blade.php ENDPATH**/ ?>