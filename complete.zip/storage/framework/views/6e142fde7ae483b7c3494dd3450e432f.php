<?php $__env->startSection("content"); ?>

<div class="col-sm-12 col-xl-12">
    <div class="bg-secondary rounded h-100 p-4">
        <h6 class="mb-4">All Categories</h6>
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">Categories Id</th>
                        <th scope="col">Categories Name</th>
                        <th scope="col">Actions</th>
                    </tr>
                </thead>
                    <tbody>
                       <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                            <td><?php echo e($row->category_id); ?></td>
                            <td><?php echo e($row->category_name); ?></td>
                            <td><a href="category_edit/<?php echo e($row->category_id); ?>/user" class="btn btn-success">Edit</a> 
                            <a href="category_delete/<?php echo e($row->category_id); ?>" class="btn btn-danger">Delete</a></td> 
                            </tr> 
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                    </tbody>
            </table>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravelPosGroup4IDB-main\resources\views/pages/Categories/viewCategories.blade.php ENDPATH**/ ?>