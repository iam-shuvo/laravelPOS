<?php $__env->startSection('content'); ?>
    <div class="col-sm-12 col-xl-12">
        <div class="p-4 rounded bg-light h-100">
            <h6 class="mb-4 bg-light">All Purchases Order</h6>
            <table class="table text-dark">
                <thead>
                    <tr>
                        <th scope="col">Order ID</th>
                        <th scope="col">Sales Man</th>
                        <th scope="col">Supplier Name</th>
                        <th>Time</th>
                        <th>Date</th>
                        <th>View</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $purchaseOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchaseOrder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($purchaseOrder->id); ?></td>
                            <td><?php echo e($purchaseOrder->user->name); ?></td>
                            <td><?php echo e($purchaseOrder->supplier->supp_name); ?></td>
                            <td><?php echo e($purchaseOrder->created_at->format('h:i a')); ?></td>
                            <td><?php echo e($purchaseOrder->created_at->format('d-M-Y')); ?></td>
                            <td>
                                <a href="<?php echo e(route('order.purchase-order.show', $purchaseOrder->id)); ?>">
                                    <button class="btn btn-success">View Purchases Order</button>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\fiamal\laravelPosGroup4IDB-main\resources\views/pages/purchaseorders/all_purchase_order.blade.php ENDPATH**/ ?>