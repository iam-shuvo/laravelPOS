
<?php $__env->startSection("content"); ?>

<div class="col-sm-12 col-xl-12">
    <div class="bg-light text-dark rounded h-100 p-4">
        <h6 class="mb-4">All Products</h6>
            <table class="table text-dark">
                <thead>
                    <tr>
                        <th scope="col">Product Name</th>
                        <th scope="col">Category</th>
                        <th scope="col">Brand</th>
                        <th scope="col">Description</th>
                        <th scope="col">Image</th>
                        <th scope="col">Stock</th>
                        
                        
                        
                        
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($row->product_name); ?></td>
                    <td><?php echo e($row->category_name); ?></td>
                    <td><?php echo e($row->brand_name); ?></td>
                    <td><?php echo e($row->description); ?></td>
                    <td><img src="<?php echo e("/uploads/".$row->product_image); ?>" style="width:60px; height:60px;"></td>
                    <td><?php echo e($row->stock); ?></td>
                  
                    

                </tr>


                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make("master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\fiamal\laravelPosGroup4IDB-main\resources\views/inventory.blade.php ENDPATH**/ ?>