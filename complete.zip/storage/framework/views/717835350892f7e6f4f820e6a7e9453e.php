<?php $__env->startSection("content"); ?>

<div class="col-sm-12 col-xl-12">
    <div class="bg-light rounded h-100 p-4">
        <h6 class="mb-4">All Units</h6>
            <table class="table text-dark">
                <thead>
                    <tr>
                        <th scope="col">Unit Id</th>
                        <th scope="col">Unit Name</th>
                        <th scope="col">Actions</th>
                    </tr>
                </thead>
                    <tbody>
                       <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                            <td><?php echo e($row->id); ?></td>
                            <td><?php echo e($row->unit_name); ?></td>
                            <td><a href="unit_edit/<?php echo e($row->unit_id); ?>/user" class="btn btn-success">Edit</a>
                            <a href="unit_delete/<?php echo e($row->unit_id); ?>" class="btn btn-danger">Delete</a></td>
                            </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
            </table>
    </div>
</div>






<?php $__env->stopSection(); ?>

<?php echo $__env->make("master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\fiamal\laravelPosGroup4IDB-main\resources\views/pages/Units/viewUnits.blade.php ENDPATH**/ ?>